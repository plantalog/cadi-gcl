/** Automatically generated file. DO NOT MODIFY */
package com.cadi.monitor;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}